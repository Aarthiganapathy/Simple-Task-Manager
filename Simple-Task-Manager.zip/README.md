Simple Task Manager

Overview
The Simple Task Manager is a web application built using the Laravel framework, Bootstrap, and jQuery. It allows users to manage tasks efficiently by providing essential CRUD (Create, Read, Update, Delete) functionality.

